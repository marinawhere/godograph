f = open('24-2.txt').readlines()
count = 0
for i in f:
    if i.count('E') > i.count('A'):
        count += 1
print(count)