f = open('24-1.txt').readlines()
list1 = [0] * 26
m = 10**8
for i in range(len(f)):
    if f[i].count('N') < m:
        m = f[i].count('N')
        index = i
s = f[index]
alf = 'ABCDEGJHIJKLMNOPQRSTUVWXYZ'
list2 = []
for i in alf:
    list2.append([s.count(i), i])
print(max(list2))
