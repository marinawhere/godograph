f = open('24-3.txt').readline()
f1 = f.split('A')
print(f1)
list2 = []
for i in f1:
    l = len(i)
    list2.append(l)
m = list2[0] + list2[1] -1
for i in range(len(list2) - 1):
    k = list2[i] + list2[i + 1] + 1
    m = max(m, k)
print(m)