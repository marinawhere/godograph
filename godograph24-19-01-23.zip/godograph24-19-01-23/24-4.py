f = open('24-4.txt').readline()
alf = 'ABCDEGJHIJKLMNOPQRSTUVWXYZ'
list2 = []
# for i in alf:
#     s = 'E' + i
#     list2.append([f.count(s), i])
#
# print(max(list2))

print(ord("Z"))
m = [0] * 26

for i in range(len(f) - 1):
    if f[i] == "E":
        m[ord(f[i+1]) - 65] += 1
for i in range(len(m)):
    print(chr(i + 65), m[i])


